<?php
require_once (dirname(__DIR__) . '/optipicimage.class.php');
class OptiPicImage_mysql extends OptiPicImage {}