<?php

$_lang['area_optipic_main'] = 'Main';

$_lang['setting_optipic_secretkey'] = 'Secret key';
$_lang['setting_optipic_secretkey_desc'] = 'Secret key from OptiPic control panel';
$_lang['setting_optipic_smushit'] = 'SmushIt';
$_lang['setting_optipic_smushit_desc'] = 'Smush image before optimisation';