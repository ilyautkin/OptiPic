--------------------
OptiPic
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX addon for https://optipic.io/ru/