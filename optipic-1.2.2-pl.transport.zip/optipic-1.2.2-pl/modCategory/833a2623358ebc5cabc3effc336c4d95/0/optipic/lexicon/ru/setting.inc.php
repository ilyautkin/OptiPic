<?php

$_lang['area_optipic_main'] = 'Основные';

$_lang['setting_optipic_secretkey'] = 'Секретный ключ';
$_lang['setting_optipic_secretkey_desc'] = 'Секретный ключ из личного кабинета OptiPic';
$_lang['setting_optipic_smushit'] = 'Использовать SmushIt';
$_lang['setting_optipic_smushit_desc'] = 'Сжимать изображение перед оптимизацией?';