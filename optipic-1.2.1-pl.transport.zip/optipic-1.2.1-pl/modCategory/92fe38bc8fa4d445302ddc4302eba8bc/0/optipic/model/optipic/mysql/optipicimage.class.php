<?php
require_once (dirname(dirname(__FILE__)) . '/optipicimage.class.php');
class OptiPicImage_mysql extends OptiPicImage {}