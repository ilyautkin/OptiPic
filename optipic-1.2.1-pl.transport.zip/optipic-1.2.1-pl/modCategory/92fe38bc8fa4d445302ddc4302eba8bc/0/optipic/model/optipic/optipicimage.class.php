<?php
class OptiPicImage extends xPDOSimpleObject {}